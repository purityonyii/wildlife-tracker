// This file connects my Express app to Vercel
const app = require("../server");

module.exports = app;
